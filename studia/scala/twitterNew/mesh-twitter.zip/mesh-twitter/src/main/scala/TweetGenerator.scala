import java.util.Calendar

import scala.collection.mutable
import scala.util.Random

class GenMessage(date: Calendar,
                 text: String)

class TweetGenerator(myName: String, nodeName: Set[String]) {
  val tweets = new mutable.HashMap[Calendar, GenMessage]()
  val random = new Random()
  val messageTemplates = Array(
    "I am posting about # and #.",
    "I hate #.",
    "Today I went with # and # to a party at #.",
    "I am so alone.",
    "# and #, let's go party!"
  )
  var nodeNames = nodeName

  postTweet("n1 cos tam cos tam")
  postTweet("n2 i n3 idą na imprezę")

  def generateTweet() = {

  }

  def generateMessage(): GenMessage = {
    val text = Random.shuffle(messageTemplates.toList).head.split(" ").map(w => w match {
      case "#" => Random.shuffle(nodeNames).head
      case _ => w
    }).mkString(" ")
    return new GenMessage(Calendar.getInstance(), text)
  }

  def postTweet(text: String) = {
    val currentDate = Calendar.getInstance()
    tweets.put(currentDate, new GenMessage(currentDate, text))
  }
}
