import java.net.InetSocketAddress
import java.text.SimpleDateFormat
import java.util.Calendar

import akka.actor._
import akka.event.Logging

import scala.collection.{immutable, mutable}

class LocalNode(myName: String, socket: InetSocketAddress, consoleHandler: ActorRef) extends Actor {

  import context.system

  val log = Logging(context.system, this)
  val name = myName
  val otherNodesRouting = new mutable.HashMap[String, RemoteNode]()
  val nodes = new mutable.HashMap[String, RemoteNode]()
  val receivedMessageIds = new mutable.HashSet[String]()
  val senders = new mutable.HashMap[RemoteNode, ActorRef]()
  val actualTweetsState = new mutable.MutableList[GenMessage]()

  val me = new RemoteNode(name, socket)
  var routing = RoutingType.Flooding

  override def receive: Receive = {
    case msg: Message => handleMessage(msg)
    case msg: ConsoleCommand => handleConsoleCommand(msg)
  }

  def this(name: String,
           socket: InetSocketAddress,
           consoleHandler: ActorRef,
           firstNeighbourHostname: String,
           firstNeighbourPort: Int) = {
    this(name, socket: InetSocketAddress, consoleHandler)

    val firstNeighbour = new RemoteNode("", new InetSocketAddress(firstNeighbourHostname, firstNeighbourPort))

    log.info("Sending connection request to {}:{}.", firstNeighbourHostname, firstNeighbourPort)

    val sen = system.actorOf(Props(new Sender(firstNeighbour.socket)))
    Thread.sleep(500)
    val id = getNextId()
    sen ! ConnectMessage(me, id, me)
    receivedMessageIds.add(id)
  }

  private def handleMessage(msg: Message) = {
    msg match {
      case _: NewConnectionMessage => NewConnectionMessageReceive(msg.sender, msg.id, msg.routingTable)
      case m: ConnectMessage => ConnectMessageReceive(m)
      case _: DisconnectMessage => DisconnectMessageReceive(msg.sender, msg.id, msg.forwarder)
      case _: WrongNameMessage => WrongNameMessageReceive(msg.sender, msg.id)
      case _: GatherRequestMessage => GatherRequestReceive(msg.sender, msg.id, msg.target, msg.numberOfTweets)
      case _: GatherResponseMessage => GatherResponseReceive(msg.sender, msg.id, msg.tweets)
      case _ => throw new Exception("invalid message")
    }
  }

  private def handleConsoleCommand(msg: ConsoleCommand) = {
    msg match {
      case _: ExitCommand => system.shutdown()
      case _: DisconnectCommand => sendDisconnectMessage()
      case _: ShowRoutingCommand => prepareRoutingTable()
      //todo inne warunki
    }
  }

  private def NewConnectionMessageReceive(sender: RemoteNode, id: String, routingTable: immutable.Map[String, RemoteNode]) = {
    addNewNeighbour(sender)

    // Przeszukujemy tablicę routingu kogoś, kto robi z nami bezpośrednie połączenie,
    // jeśli ten ktoś ma lepsze połączenia, wrzucamy je do swojej tablicy
    routingTable.foreach(item => {
      if (item._2.name != me.name) {
        if (otherNodesRouting.contains(item._1)) {
          if (sender == item._2) {
            otherNodesRouting.remove(item._1)
            otherNodesRouting.put(item._1, nodes.get(sender.name).get)
          }
        } else {
          nodes.put(item._1, new RemoteNode(item._1, item._2.socket))
          otherNodesRouting.put(item._1, nodes.get(sender.name).get)
        }
      }
    })

    log.info("Got NewConnectionMessage: {}, {}", sender.name, id)
  }

  private def ConnectMessageReceive(msg: ConnectMessage): Unit = {
    // Ilość %, że powstanie nowe połączenie

    if (!receivedMessageIds.contains(msg.id)) {
      receivedMessageIds.add(msg.id)

      val sender = msg.sender

      log.info("Got ConnectMessage: {}, {}, {}", msg.sender.name, msg.id, msg.forwarder.name)

      if (sender.name == name || nodes.contains(sender.name)) {
        val temp = system.actorOf(Props(new Sender(sender.socket))) // COŚ TU NIE TAK
        Thread.sleep(200)
        temp ! WrongNameMessage(me, msg.id)
        return
      }

      if (msg.forwarder.name == sender.name /*|| Random.nextInt(100) < threshold*/ ) {
        val id = getNextId()
        addNewNeighbour(sender)
        Thread.sleep(200)
        senders.get(nodes.get(sender.name).get).get ! NewConnectionMessage(me, id, otherNodesRouting.toMap)
      } else {
        otherNodesRouting.put(sender.name, nodes.get(msg.forwarder.name).get)
      }

      forwardMessage(msg)
    }
  }

  private def DisconnectMessageReceive(sender: RemoteNode, id: String, forwarder: RemoteNode) = {
    if (!receivedMessageIds.contains(id)) {
      //println(": otrzymalem disconnectMessage od " + sender.name + " o id = " + id.toString())
      receivedMessageIds.add(id)
      deleteNeighbour(sender)

      forwardMessage(new DisconnectMessage(sender, id, forwarder))

      // todo: dołożyć obsługęe partycji sieci
    }
  }

  private def WrongNameMessageReceive(sender: RemoteNode, id: String) = {
    println("Host name in this network already exists. Take another one and try again.")
    system.shutdown()
  }

  private def GatherRequestReceive(sender: RemoteNode, id: String, target: String, numberOfTweets: Int) = {
    // odbieranie requesta
    ???
  }

  private def GatherResponseReceive(sender: RemoteNode, id: String, tweets: List[GenMessage]) = {
    // odbieranie response
    ???
  }

  private def sendConnectMessage(node: RemoteNode) = {
    val id = getNextId()
    senders.get(node).get ! ConnectMessage(me, id, me)
    receivedMessageIds.add(id)
  }

  private def getNextId(): String = {
    val format = new SimpleDateFormat("dd-hh-mm-ss-SSS")
    name + "_" + format.format(Calendar.getInstance().getTime)
  }

  private def sendDisconnectMessage() = {
    val id = getNextId()
    receivedMessageIds.add(id)
    senders.foreach(item => {
      item._2 ! DisconnectMessage(me, id, me)
    })
  }

  private def forwardMessage(msg: Message) = {
    routing match {
      case RoutingType.Flooding => floodingForwardMessage(msg)
      case RoutingType.Routing => routingForwardMessage(msg)
    }
  }

  private def floodingForwardMessage(msg: Message) = {
    senders.foreach(item => {
      if (item._1.name != msg.forwarder.name && item._1.name != msg.sender.name) {
        msg match {
          case _: ConnectMessage => item._2 ! ConnectMessage(msg.sender, msg.id, me)
          case _: DisconnectMessage => item._2 ! DisconnectMessage(msg.sender, msg.id, me)
          // todo other actions
        }
      }
    })
  }

  private def routingForwardMessage(msg: Message) = {
    // todo
  }

  private def addNewNeighbour(node: RemoteNode) = {
    if (!senders.contains(node)) {
      if (!nodes.contains(node.name))               nodes.put(node.name, node)
      if (!otherNodesRouting.contains(node.name))   otherNodesRouting.put(node.name, nodes.get(node.name).get)
      senders.put(nodes.get(node.name).get, system.actorOf(Props(new Sender(node.socket))))
    }
  }

  private def deleteNeighbour(node: RemoteNode) = {
    if (senders.contains(nodes.get(node.name).get)) senders.remove(nodes.get(node.name).get)
    if (otherNodesRouting.contains(node.name)) otherNodesRouting.remove(node.name)
    if (nodes.contains(node.name)) nodes.remove(node.name)

  }

  private def prepareRoutingTable() = {
    val neighbours = new mutable.HashMap[String, List[String]]()
    senders.keySet.foreach(s => {
      neighbours.put(s.name, otherNodesRouting.get(s.name).map(f => f.name).filter(f => f != s.name).toList)
    })
    consoleHandler ! new ShowRoutingReplyCommand(neighbours.toMap)
  }
}

class RemoteNode(nodeName: String, sock: InetSocketAddress) extends Serializable {
  val name = nodeName
  val socket = sock

  def this(sock: InetSocketAddress) = this("", sock)
}

object RoutingType extends Enumeration {
  val Routing = Value("routing")
  val Flooding = Value("flooding")
}