import java.net.InetSocketAddress

import akka.actor.{Actor, ActorSystem, Props}

object Main {

  def main(args: Array[String]) {

    if (args.length != 2 && args.length != 4) {
      println("usage: " +
        "./run [clientName] [clientPort]\n" +
        "or: " +
        "./run [clientName] [clientPort] [firstNeighbourHostname] [firstNeighbourPort]")
      return
    }

    if (!args(1).matches("^\\d*$") || (args.length == 4 && !args(3).matches("^\\d*$"))) {
      println("Bad port number.")
      return
    }

    val system = ActorSystem("MeshTwitterSystem")
    val nodeName = args(0)
    val localPort = args(1).toInt
    val callbackHandler = system.actorOf(Props(new ConsoleCallbackHandler))

    val mainNode = system.actorOf(Props(args.length match {
      case 2 => new LocalNode(nodeName, new InetSocketAddress("localhost", localPort), callbackHandler)
      case 4 => {
        val remoteHost = args(2)
        val remotePort = args(3).toInt
        new LocalNode(nodeName, new InetSocketAddress("localhost", localPort), callbackHandler, remoteHost, remotePort)
      }
    }))

    val listener = system.actorOf(Props(new Listener(localPort, mainNode)))

    while (true) {
      try {
        print("% ")

        val command: Array[String] = scala.io.StdIn.readLine().trim().split(" +")

        command(0) match {
          case "exit" | "disconnect" => {
            println("Sending Disconnect message to peers.")
            mainNode ! new DisconnectCommand
            mainNode ! new ExitCommand
            Thread.sleep(1000)
            println("Exiting.")
            return
          }
          case "gather" => {
            if (command.length == 3 && command(2).matches("^\\d*$")) {
              mainNode ! new GatherCommand(command(1), command(2).toInt)
              //todo read
            } else
              println("Wrong arguments. ")
          }
          case "routing" => {
            if (command.length == 2 && (command(1) == "routing" || command(1) == "flooding")) {
              val routing = RoutingType.withName(command(1))
              mainNode ! new RoutingTypeCommand(routing)
              println("Routing changed to {}.", routing)
            } else
              println("Wrong arguments. ")
          }
          case "show" => {
            mainNode ! new ShowRoutingCommand
          }
          case "messages" => {
            //            mainNode.receivedMessageIds.foreach(item => {
            //              println("\t" + item._2.getClass.toString + "(" + item._2.sender.name + ", " + item._2.id + ")")
            //              println(item)
            //            })
            //todo
          }
          case _ => println("Available commands:\n" +
            "\tshow\n" +
            "\texit\n" +
            "\tgather [target] [number of tweets]\n" +
            "\trouting [routing/flooding]\n" +
            "\tmessages")
        }
        Thread.sleep(100)
      } catch {
        case e: Exception => {
          e.printStackTrace()
          println("An error occurred. Exiting.")
          return
        }
      }
    }
  }

  class ConsoleCallbackHandler extends Actor {
    override def receive: Receive = {
      case s: ShowRoutingReplyCommand => {
        if (s.routingTable.isEmpty) {
          println("Nobody is connected.")
        }
        s.routingTable.foreach(n => {
          print(n._1 + " -> ")
          n._2.foreach(n => print(n + " "))
          println
        })
      }
      case msg => println(msg)
    }
  }

}
