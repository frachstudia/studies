import scala.collection.immutable

// id to zlepek <nodeName>_<id>
// np. node1_1, node1_2, node1_3, itd.
sealed trait Message extends Serializable {
  val sender: RemoteNode
  val id: String
  val forwarder: RemoteNode = sender
  val numberOfTweets: Int = 0
  val target: String = null
  val tweets: List[GenMessage] = null
  val routingTable: immutable.Map[String, RemoteNode] = null
}

case class NewConnectionMessage(sender: RemoteNode,
                                val id: String,
                                override val routingTable: immutable.Map[String, RemoteNode]) extends Message

case class ConnectMessage(sender: RemoteNode,
                          id: String,
                          override val forwarder: RemoteNode) extends Message

case class DisconnectMessage(sender: RemoteNode,
                             id: String,
                             override val forwarder: RemoteNode) extends Message

case class GatherRequestMessage(sender: RemoteNode,
                                id: String,
                                override val target: String,
                                override val numberOfTweets: Int) extends Message

case class GatherResponseMessage(sender: RemoteNode,
                                 id: String,
                                 override val tweets: List[GenMessage]) extends Message

case class WrongNameMessage(sender: RemoteNode,
                            id: String) extends Message

