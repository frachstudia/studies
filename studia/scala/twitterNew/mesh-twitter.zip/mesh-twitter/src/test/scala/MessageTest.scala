import org.scalatest._

import scala.collection.mutable.Stack

class MessageTest extends FlatSpec with Matchers {
/*
  "Message references" should "return the set of mentioned node names" in {
    val testMessage = "I am #!@# gossiping ## about #node1 and my friend #node2 is listening. #1234 #abc"
    val msg = new Message(testMessage)

    msg.references should contain("node1")
    msg.references should contain("node2")
    msg.references should contain("abc")
    msg.references should contain("1234")
    msg.references should not contain ("")
    msg.references should have size 4
  }*/
}
