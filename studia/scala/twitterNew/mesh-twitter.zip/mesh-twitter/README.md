# meshtwitter

Import do IntelliJ
==================

Importuje się normalnie przez Import..., następnie wybrać SBT.

Uruchamianie
============

Ja uruchamiam z konsoli:

sbt run